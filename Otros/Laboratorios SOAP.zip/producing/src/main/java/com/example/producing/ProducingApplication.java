package com.example.producing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProducingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProducingApplication.class, args);
	}

}
