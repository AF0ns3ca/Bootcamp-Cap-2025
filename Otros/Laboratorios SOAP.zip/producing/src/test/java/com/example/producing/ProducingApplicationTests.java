package com.example.producing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducingApplicationTests {

	@Test
	void contextLoads() {
	}

}
